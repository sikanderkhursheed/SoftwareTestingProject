package org.checkstyle.suppressionxpathfilter.parenpad;

public class SuppressionXpathRegressionParenPadRightPreceded {
    void method() {
        if (false ) {//warn
        }
        if (true) {
        }
    }
}
