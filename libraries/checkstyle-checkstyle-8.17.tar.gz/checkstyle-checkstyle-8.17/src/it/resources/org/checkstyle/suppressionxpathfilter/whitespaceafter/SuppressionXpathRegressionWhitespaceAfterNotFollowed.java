package org.checkstyle.suppressionxpathfilter.whitespaceafter;

public class SuppressionXpathRegressionWhitespaceAfterNotFollowed {
    int[] bad = {1,2}; //warn
    int[] good = {1, 2};
}
