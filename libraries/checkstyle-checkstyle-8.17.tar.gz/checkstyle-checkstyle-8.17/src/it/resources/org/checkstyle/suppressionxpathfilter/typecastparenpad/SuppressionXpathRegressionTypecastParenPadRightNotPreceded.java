package org.checkstyle.suppressionxpathfilter.typecastparenpad;

public class SuppressionXpathRegressionTypecastParenPadRightNotPreceded{
    Object bad = ( Object)null;//warn
    Object good = ( Object )null;
}
