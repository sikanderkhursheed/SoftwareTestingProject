package org.checkstyle.suppressionxpathfilter.methodparampad;

public class SuppressionXpathRegressionMethodParamPadTwo {
    public void sayHello
            (String name) { //warn

    }
}
