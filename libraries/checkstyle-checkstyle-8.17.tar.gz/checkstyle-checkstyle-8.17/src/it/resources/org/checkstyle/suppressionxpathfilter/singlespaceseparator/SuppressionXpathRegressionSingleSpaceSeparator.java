package org.checkstyle.suppressionxpathfilter.singlespaceseparator;

public class SuppressionXpathRegressionSingleSpaceSeparator {
    long  bad;//warn
    long good;
}
