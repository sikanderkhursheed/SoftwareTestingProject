package org.checkstyle.suppressionxpathfilter.javadocvariable;

public class SuppressionXpathRegressionJavadocVariableTwo {
    class InnerInner2
    {
        public int fData; //warn
    }
}
