package org.checkstyle.suppressionxpathfilter.methodparampad;

public class SuppressionXpathRegressionMethodParamPadOne {
    public void InputMethodParamPad (int aParam) { //warn
    }
}
