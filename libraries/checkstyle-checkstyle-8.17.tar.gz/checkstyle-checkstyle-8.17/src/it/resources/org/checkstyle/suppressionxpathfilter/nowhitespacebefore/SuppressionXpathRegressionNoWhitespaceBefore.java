package org.checkstyle.suppressionxpathfilter.nowhitespacebefore;

public class SuppressionXpathRegressionNoWhitespaceBefore {
    int bad ;//warn
    int good;
}
