package org.checkstyle.suppressionxpathfilter.javadocvariable;

public class SuppressionXpathRegressionJavadocVariableOne {

    private int age; //warn

    public void helloWorld(String name)
    {
    }
}
