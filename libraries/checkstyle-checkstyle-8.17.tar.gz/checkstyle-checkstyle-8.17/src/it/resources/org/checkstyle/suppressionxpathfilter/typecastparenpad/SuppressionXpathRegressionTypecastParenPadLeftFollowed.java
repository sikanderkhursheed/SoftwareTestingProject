package org.checkstyle.suppressionxpathfilter.typecastparenpad;

public class SuppressionXpathRegressionTypecastParenPadLeftFollowed {
    Object bad = ( Object)null;//warn
    Object good = (Object)null;
}
