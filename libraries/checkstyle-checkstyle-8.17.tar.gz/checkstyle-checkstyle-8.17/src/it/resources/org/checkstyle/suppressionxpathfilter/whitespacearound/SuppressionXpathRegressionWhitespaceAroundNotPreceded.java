package org.checkstyle.suppressionxpathfilter.whitespaceafter;

public class SuppressionXpathRegressionWhitespaceAroundNotPreceded {
    int bad= 0; //warn
    int good = 0;
}
