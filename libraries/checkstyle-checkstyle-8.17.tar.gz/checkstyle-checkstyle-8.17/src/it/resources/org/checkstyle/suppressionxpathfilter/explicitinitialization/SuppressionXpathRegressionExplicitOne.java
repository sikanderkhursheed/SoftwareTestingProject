package org.checkstyle.suppressionxpathfilter.explicitinitialization;

public class SuppressionXpathRegressionExplicitOne {
    private int a = 0; //warn
}
