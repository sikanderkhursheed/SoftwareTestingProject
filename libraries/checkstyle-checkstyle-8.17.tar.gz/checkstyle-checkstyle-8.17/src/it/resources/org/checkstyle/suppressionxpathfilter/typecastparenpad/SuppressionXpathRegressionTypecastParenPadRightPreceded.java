package org.checkstyle.suppressionxpathfilter.typecastparenpad;

public class SuppressionXpathRegressionTypecastParenPadRightPreceded {
    Object bad = (Object )null;//warn
    Object good = (Object)null;
}
