package org.checkstyle.suppressionxpathfilter.leftcurly;

public class SuppressionXpathRegressionLeftCurlyTwo { //warn
}
